import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { AcademicResource, Scholarship, StudentProject, GeneratedQuiz, StudyPlan } from "./src/types";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initial Seed Data
let resources: AcademicResource[] = [
  {
    id: "r1",
    title: "Advanced Calculus Lecture Notes",
    subject: "Mathematics",
    type: "note",
    description: "Comprehensive notes covering double integrals, vector calculus, Green's theorem, and Stokes' theorem with detailed solved proofs.",
    content: "# Advanced Calculus Notes\n\n## Vector Calculus Foundations\nScalar and vector fields describe physics in space. Gradient of scalar function gives the direction of steepest ascent.\n\n### Green's Theorem\n$$\\oint_C (P \\, dx + Q \\, dy) = \\iint_D \\left(\\frac{\\partial Q}{\\partial x} - \\frac{\\partial P}{\\partial y}\\right) dx \\, dy$$\nUsed extensively in fluid dynamics and gravitational field integrations.",
    author: "Sarah Johnson",
    date: "2026-06-15",
    downloads: 142
  },
  {
    id: "r2",
    title: "Intro to Quantum Mechanics Past Paper (2024)",
    subject: "Physics",
    type: "paper",
    description: "Official mid-term examination paper with detailed handwritten step-by-step solutions for Schrodinger wave equations.",
    content: "# Quantum Mechanics Mid-term 2024\n\n## Question 1: Infinite Square Well\nConsider a particle in an infinite 1D potential well of width L. Find the normalized wave functions and energy levels.\n\n## Solution:\n$$\\psi_n(x) = \\sqrt{\\frac{2}{L}} \\sin\\left(\\frac{n\\pi x}{L}\\right)$$\n$$E_n = \\frac{n^2 \\pi^2 \\hbar^2}{2m L^2}$$",
    author: "Physics Dept Club",
    date: "2026-05-10",
    downloads: 289
  },
  {
    id: "r3",
    title: "Linear Algebra Survival Guide",
    subject: "Mathematics",
    type: "guide",
    description: "A cheatsheet for eigenvalues, eigenvectors, matrix diagonalization, and singular value decomposition (SVD).",
    content: "# Linear Algebra Study Cheat Sheet\n\n- **Determinant of 2x2 matrix**: $ad - bc$\n- **Eigenvalue equation**: $A v = \\lambda v$\n- **Diagonalization condition**: Matrix $A$ of size $n \\times n$ is diagonalizable if and only if it has $n$ linearly independent eigenvectors.\n- **Singular Value Decomposition**: $A = U \\Sigma V^T$",
    author: "Prof. Gilbert Fan",
    date: "2026-07-01",
    downloads: 410
  },
  {
    id: "r4",
    title: "Deep Learning Lecture Slides & Summaries",
    subject: "Computer Science",
    type: "note",
    description: "Notes on convolutional neural networks, backpropagation math, attention mechanisms, and transformer architectures.",
    content: "# Deep Learning Notes\n\n## Backpropagation Rules\nChain rule is used to compute gradients recursively from the loss layer back to inputs:\n$$\\frac{\\partial L}{\\partial w} = \\frac{\\partial L}{\\partial y} \\cdot \\frac{\\partial y}{\\partial z} \\cdot \\frac{\\partial z}{\\partial w}$$\n\n## Attention Mechanism\n$$Attention(Q, K, V) = \\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)V$$",
    author: "Dr. Alan Turing Jr.",
    date: "2026-04-20",
    downloads: 512
  }
];

let scholarships: Scholarship[] = [
  {
    id: "s1",
    name: "STEM Pioneer Excellence Scholarship / STEM 개척자 우수 장학금",
    description: "Annual scholarship awarded to undergraduate students showing exceptional promise, leadership, and research projects in Science, Technology, Engineering, or Math. / 과학, 기술, 공학 및 수학 분야에서 우수한 성과와 리더십을 보여주는 학부생 대상 장학금.",
    amount: "₩5,000,000",
    eligibility: "GPA 3.5+, Major in STEM, undergraduate status / 평점 3.5 이상, 이공계열 전공 학부생",
    deadline: "2026-11-15",
    category: "merit",
    link: "https://example.edu/scholarships/stem-pioneer"
  },
  {
    id: "s2",
    name: "Global Equal Opportunity Grant / 글로벌 균등 기회 장학금",
    description: "Need-based financial grant aimed at international and underrepresented minority students to complete their higher education. / 유학생 및 소외 계층 학생들의 학업 완수를 지원하기 위한 생활비 보조 성격의 장학금.",
    amount: "₩12,000,000",
    eligibility: "GPA 3.0+, proven financial need, full-time enrollment / 평점 3.0 이상, 재정적 지원 필요 증빙 가능자, 전일제 재학생",
    deadline: "2026-10-30",
    category: "financial",
    link: "https://example.edu/scholarships/global-equal"
  },
  {
    id: "s3",
    name: "Ada Lovelace Computing Fellowship / 에이다 러브레이스 컴퓨터 펠로우십",
    description: "Fellowship dedicated to fostering female excellence in Computer Science, Software Engineering, and Artificial Intelligence research. / 컴퓨터 과학, 소프트웨어 공학 및 인공지능 연구 분야의 우수한 여성 인재 양성을 위한 펠로우십.",
    amount: "₩10,000,000 + 멘토링",
    eligibility: "Female-identifying, GPA 3.6+, Computer Science or related major / 여성 학부생, 평점 3.6 이상, 컴퓨터공학 및 관련 전공",
    deadline: "2027-01-20",
    category: "minority",
    link: "https://example.edu/scholarships/ada-lovelace"
  },
  {
    id: "s4",
    name: "Community Impact Catalyst Award / 지역사회 기여 촉매 장학금",
    description: "For students who demonstrate substantial commitment to civic responsibility, local volunteerism, or socially-minded technology projects. / 시민적 책임감, 지역 사회 봉사, 또는 사회적 공헌 기술 프로젝트 참여도가 높은 학생 대상 장학금.",
    amount: "₩4,000,000",
    eligibility: "Open to all majors, minimum 50 documented volunteer hours / 전공 무관, 최소 50시간 이상의 인증 봉사 시간 보유자",
    deadline: "2026-09-30",
    category: "general",
    link: "https://example.edu/scholarships/community-impact"
  }
];

let studentProjects: StudentProject[] = [
  {
    id: "p1",
    title: "Distributed Key-Value Store with Raft Consensus",
    description: "Built a fault-tolerant distributed system key-value storage engine utilizing the Raft consensus algorithm in Go for log replication, leader election, and high availability.",
    subject: "Computer Science",
    category: "software",
    techStack: ["Go", "Raft", "gRPC", "Docker"],
    author: "Evelyn Reed",
    stars: 42,
    codeUrl: "https://github.com/evelyn/raft-kv",
    demoUrl: "https://raft-demo.evelyn.dev",
    feedback: [
      "Outstanding implementation of Raft consensus protocol. The partition recovery simulations are robust.",
      "Llama AI Assistant: Excellent technical architecture! To improve the portfolio score, consider adding benchmarks comparing read/write throughput with standard Redis cluster."
    ]
  },
  {
    id: "p2",
    title: "Acoustic Levitation & Phase-Controlled Transducers",
    description: "Designed and prototyped an acoustic levitation chamber using an array of 40kHz ultrasonic transducers controlled by an Arduino to trap and manipulate miniature styrofoam spheres.",
    subject: "Applied Physics",
    category: "engineering",
    techStack: ["Arduino", "SolidWorks", "C++", "Oscilloscopes"],
    author: "Marcus Chen",
    stars: 28,
    feedback: [
      "Llama AI Assistant: Magnificent physics project! The mechanical design documentation is highly detailed. To level up your resume, consider simulating the sound pressure nodes inside Matlab first to explain the stable equilibrium zones."
    ]
  },
  {
    id: "p3",
    title: "EcoSmart Urban Agriculture System",
    description: "An automated vertical farming platform utilizing IoT sensors, drip irrigation, and custom LED lighting spectral cycles optimized for indoor leafy vegetable growth.",
    subject: "Environmental Science",
    category: "design",
    techStack: ["React", "IoT Nodes", "ESP32", "Python", "MQTT"],
    author: "Zoe Alvarez",
    stars: 19,
    codeUrl: "https://github.com/zoe/ecosmart-farm",
    feedback: [
      "Llama AI Assistant: Brilliant sustainable solution. The system integration dashboard has highly responsive sensor data telemetry. Adding automatic fertilizer/NPK ratio control based on soil pH would make this an industry-level prototype!"
    ]
  }
];

// Lazy Gemini Client Initialization
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY environment variable is not defined. AI endpoints will fallback to high-fidelity mocks.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// ---------------- API ENDPOINTS ----------------

// 1. Chatbot API (CHOSUN UNDERGRADUATE AI theme)
app.post("/api/chatbot/chat", async (req, res) => {
  const { message, history } = req.body;
  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  const ai = getGeminiClient();
  if (!ai) {
    // Fallback Mock chatbot response acting as CHOSUN UNDERGRADUATE AI
    setTimeout(() => {
      res.json({
        reply: `🎓 *CHOSUN UNDERGRADUATE AI (Offline Mock Mode)*\n\nI received your question: "${message}". Since my live AI connection is offline, here is a premium academic strategy:\n\n* **Spaced Repetition & Recall**: Break your Chosun lectures into core active recall concepts. Review them in increasing intervals (1 day, 3 days, 7 days, 14 days) to maximize GPA stability.\n\nLet me know if there's anything else I can assist you with regarding study plans, quizzes, or past papers!`
      });
    }, 800);
    return;
  }

  try {
    // Convert history to system format or compile into a prompt
    const contextPrompt = `You are "CHOSUN UNDERGRADUATE AI", a brilliant, supportive, and highly prestigious academic advisor and student success companion at Chosun University in South Korea.
Always maintain your identity as CHOSUN UNDERGRADUATE AI. Provide premium, highly actionable study strategies, explain difficult concepts elegantly, offer GPA improvement tips, draft scholarship recommendations, and help students maximize their academic potential.
You are fully bilingual in English and Korean (한국어). Analyze the language of the student's query and respond in the same language. If they write in Korean, write in elegant, polite Korean (e.g. 존댓말, -해요체/-습니다체). If they write in English, write in fluent academic English.
Always represent currency in Korean Won (₩) (e.g. ₩5,000,000 or 500만원) instead of US dollars ($) if any currency is mentioned.

Conversation history for context:
${(history || []).map((h: any) => `${h.sender === 'user' ? 'Student' : 'CHOSUN AI'}: ${h.text}`).join('\n')}

Student's newest query: "${message}"

Provide a highly structured, encouraging, and clear markdown response.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contextPrompt,
    });

    res.json({ reply: response.text });
  } catch (error: any) {
    console.error("Gemini API error:", error);
    res.status(500).json({ error: "AI response failed to generate.", details: error.message });
  }
});

// 2. Study Plan Generation API
app.post("/api/chatbot/study-plan", async (req, res) => {
  const { subject, currentGrade, targetGpa, durationWeeks, notesText } = req.body;
  if (!subject) {
    return res.status(400).json({ error: "Subject is required." });
  }

  const weeks = Number(durationWeeks) || 4;
  const ai = getGeminiClient();

  if (!ai) {
    // Mock Study Plan
    const mockPlan: StudyPlan = {
      id: "plan_" + Date.now(),
      subject,
      targetGpa: targetGpa || "4.0",
      durationWeeks: weeks,
      gpaTips: [
        `Target active recall sessions for ${subject} instead of passive re-reading. / 수동적인 반복 읽기 대신 ${subject}에 대한 능동적 회상 세션을 목표로 하세요.`,
        "Form a study group or try teaching the concept to a friend (Feynman Technique). / 스터디 그룹을 결성하거나 친구에게 개념을 설명해 보세요 (파인만 학습법).",
        "Practice with at least two past exam papers under realistic time constraints. / 실제 시험 시간 제한 하에서 최소 2회의 기출문제를 연습하세요."
      ],
      schedule: Array.from({ length: weeks }, (_, idx) => ({
        week: idx + 1,
        focus: `Core Mastery of ${subject} - Stage ${idx + 1} / ${subject} 핵심 마스터 - ${idx + 1}단계`,
        tasks: [
          `Review lectures and core notes for Module ${idx + 1} / 모듈 ${idx + 1}의 강의 및 핵심 노트 검토`,
          `Solve 5 practice problems with solutions / 해설이 포함된 연습 문제 5개 풀기`,
          `Consult CHOSUN CO-PILOT chatbot on unresolved gaps / 해결되지 않은 공백은 조선 코파일럿 챗봇에 문의`
        ]
      }))
    };
    return res.json(mockPlan);
  }

  try {
    const prompt = `You are "CHOSUN UNDERGRADUATE AI Study Planner". Create a weekly study plan for a student trying to excel in:
Subject: ${subject}
Current Grade/Standing: ${currentGrade || "Not provided"}
Target GPA: ${targetGpa || "A / 4.0"}
Duration: ${weeks} Weeks
Supporting notes context: ${notesText || "None provided"}

You are fully bilingual. If the subject, standing, or notes contains Korean, or if you feel Korean is more appropriate, generate the focus areas, tasks, and tips in Korean. Otherwise, generate them in English, or in a beautifully paired English/Korean bilingual format.

Generate a highly optimized, academic-validated study plan in JSON format. The response must follow this JSON schema exactly:
{
  "subject": "string",
  "targetGpa": "string",
  "durationWeeks": number,
  "gpaTips": ["string"],
  "schedule": [
    {
      "week": number,
      "focus": "string",
      "tasks": ["string"]
    }
  ]
}
Do not include any wrapping markdown blocks except the raw JSON itself.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            targetGpa: { type: Type.STRING },
            durationWeeks: { type: Type.INTEGER },
            gpaTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            schedule: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  week: { type: Type.INTEGER },
                  focus: { type: Type.STRING },
                  tasks: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ["week", "focus", "tasks"]
              }
            }
          },
          required: ["subject", "targetGpa", "durationWeeks", "gpaTips", "schedule"]
        }
      }
    });

    const parsedPlan = JSON.parse(response.text.trim());
    parsedPlan.id = "plan_" + Date.now();
    res.json(parsedPlan);
  } catch (error: any) {
    console.error("AI Study Plan generator failed:", error);
    res.status(500).json({ error: "Failed to generate AI study plan.", details: error.message });
  }
});

// 3. Quiz & Explanations Generation API
app.post("/api/chatbot/generate-quiz", async (req, res) => {
  const { subject, topics, difficulty } = req.body;
  if (!subject) {
    return res.status(400).json({ error: "Subject is required." });
  }

  const diff = difficulty || "Medium";
  const ai = getGeminiClient();

  if (!ai) {
    // Return high-fidelity mock quiz
    const mockQuiz: GeneratedQuiz = {
      title: `${diff} Level Quiz on ${subject}`,
      subject,
      questions: [
        {
          questionText: `Which of the following describes the core objective of active recall in studying ${subject}?`,
          options: [
            "Re-reading the textbook chapter multiple times until it feels familiar.",
            "Testing yourself on key concepts without looking at the notes to stimulate memory retrieval.",
            "Highlighting important formulas or terms in green or yellow.",
            "Creating a visually appealing mind map using aesthetic color palettes."
          ],
          correctIndex: 1,
          explanation: "Testing yourself (active recall) forces the brain to retrieve information, which strengthens neural pathways far better than passive re-reading or highlighting."
        },
        {
          questionText: "What is the Feynman Technique named after physicist Richard Feynman?",
          options: [
            "Solving problems at the speed of light.",
            "Explaining a complex topic in simple terms to a child or beginner to identify gaps in your own knowledge.",
            "Memorizing formulas using mathematical flashcards.",
            "Reviewing notes only 10 minutes before the actual examination starts."
          ],
          correctIndex: 1,
          explanation: "The Feynman Technique involves explaining a concept simply, highlighting where your own understanding breaks down so you can target those gaps."
        }
      ]
    };
    return res.json(mockQuiz);
  }

  try {
    const prompt = `You are "CHOSUN UNDERGRADUATE AI Quizzer". Generate an interactive 3-question revision quiz to test a student's knowledge of:
Subject: ${subject}
Topics: ${topics || "General concepts"}
Difficulty Level: ${diff}

You are fully bilingual. If the subject or topics are in Korean, generate the quiz title, question texts, options, and explanations in Korean (한국어). Otherwise, generate them in English, or in a beautifully paired English/Korean bilingual format.

Generate the quiz in JSON format matching this schema:
{
  "title": "string",
  "subject": "string",
  "questions": [
    {
      "questionText": "string",
      "options": ["string", "string", "string", "string"],
      "correctIndex": number (0-3),
      "explanation": "string explaining why the correct option is right and others are wrong"
    }
  ]
}
Make sure questions are challenging and educational. Deliver raw JSON.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            subject: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  questionText: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  correctIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING }
                },
                required: ["questionText", "options", "correctIndex", "explanation"]
              }
            }
          },
          required: ["title", "subject", "questions"]
        }
      }
    });

    const parsedQuiz = JSON.parse(response.text.trim());
    res.json(parsedQuiz);
  } catch (error: any) {
    console.error("AI Quiz Generator error:", error);
    res.status(500).json({ error: "Failed to generate AI quiz.", details: error.message });
  }
});

// 4. Academic Materials APIs
app.get("/api/materials", (req, res) => {
  res.json(resources);
});

app.post("/api/materials", (req, res) => {
  const { title, subject, type, description, content, author } = req.body;
  if (!title || !subject || !type || !content) {
    return res.status(400).json({ error: "Title, subject, type, and content are required." });
  }

  const newResource: AcademicResource = {
    id: "r_" + Date.now(),
    title,
    subject,
    type,
    description: description || "",
    content,
    author: author || "Student Contributor",
    date: new Date().toISOString().split('T')[0],
    downloads: 0
  };

  resources.unshift(newResource);
  res.status(201).json(newResource);
});

app.post("/api/materials/:id/download", (req, res) => {
  const resource = resources.find(r => r.id === req.params.id);
  if (!resource) {
    return res.status(404).json({ error: "Resource not found." });
  }
  resource.downloads += 1;
  res.json({ success: true, downloads: resource.downloads });
});

// 5. Scholarships APIs
app.get("/api/scholarships", (req, res) => {
  res.json(scholarships);
});

app.post("/api/scholarships", (req, res) => {
  const { name, description, amount, eligibility, deadline, category, link } = req.body;
  if (!name || !amount || !deadline || !category) {
    return res.status(400).json({ error: "Name, amount, deadline, and category are required." });
  }

  const newScholarship: Scholarship = {
    id: "s_" + Date.now(),
    name,
    description: description || "",
    amount,
    eligibility: eligibility || "Open to all students",
    deadline,
    category,
    link: link || "#"
  };

  scholarships.push(newScholarship);
  res.status(201).json(newScholarship);
});

// 6. Student Projects & AI Feedback APIs
app.get("/api/projects", (req, res) => {
  res.json(studentProjects);
});

app.post("/api/projects", (req, res) => {
  const { title, description, subject, category, techStack, author, codeUrl, demoUrl } = req.body;
  if (!title || !description || !subject || !category) {
    return res.status(400).json({ error: "Title, description, subject, and category are required." });
  }

  const newProject: StudentProject = {
    id: "p_" + Date.now(),
    title,
    description,
    subject,
    category,
    techStack: techStack || [],
    author: author || "Student Developer",
    stars: 0,
    codeUrl,
    demoUrl,
    feedback: [
      "Llama AI Assistant: Project successfully registered in the portal! Request a full AI Portfolio review above to get detailed feedback and GPA improvement suggestions."
    ]
  };

  studentProjects.unshift(newProject);
  res.status(201).json(newProject);
});

// Upvote/Star a project
app.post("/api/projects/:id/star", (req, res) => {
  const project = studentProjects.find(p => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: "Project not found." });
  }
  project.stars += 1;
  res.json({ success: true, stars: project.stars });
});

// Request specialized Llama AI Review / feedback for a student project
app.post("/api/projects/:id/ai-review", async (req, res) => {
  const project = studentProjects.find(p => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: "Project not found." });
  }

  const ai = getGeminiClient();
  if (!ai) {
    // Offline / Mock Review
    const mockFeedbacks = [
      "🎓 CHOSUN UNDERGRADUATE AI: Magnificent codebase structure. We suggest adding unit tests for any core database layers to protect state stability.",
      "🎓 CHOSUN UNDERGRADUATE AI: Your portfolio looks incredible! To boost your academic score, try publishing an engineering blog post detailing how your tech stack handles high throughput.",
      "🎓 CHOSUN UNDERGRADUATE AI: Consider implementing continuous integration (CI) workflows using GitHub Actions to demonstrate professional standards."
    ];
    const randomReview = mockFeedbacks[Math.floor(Math.random() * mockFeedbacks.length)];
    if (!project.feedback) project.feedback = [];
    project.feedback.push(randomReview);
    return res.json({ success: true, feedback: project.feedback });
  }

  try {
    const prompt = `You are "CHOSUN UNDERGRADUATE AI Portfolio Reviewer", an expert academic and engineering reviewer at Chosun University.
Analyze this student project:
Title: ${project.title}
Description: ${project.description}
Subject/Category: ${project.subject} / ${project.category}
Tech Stack: ${project.techStack.join(', ')}

You are fully bilingual. Analyze the language of the title and description and write the peer review in that same language (English or Korean). If the title/description contains Korean, respond in polite, academic Korean.
Provide a highly constructive, expert peer review in exactly 2-3 sentences. Identify one stellar technical achievement and offer one clear suggestion on how they could level up this project to make it look industry-ready or secure top research grades. Prefix your feedback with "🎓 CHOSUN UNDERGRADUATE AI: "`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    if (!project.feedback) project.feedback = [];
    project.feedback.push(response.text.trim());
    res.json({ success: true, feedback: project.feedback });
  } catch (error: any) {
    console.error("AI Portfolio review error:", error);
    res.status(500).json({ error: "AI Review failed.", details: error.message });
  }
});


// Handle Vite and Client Route serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server successfully started on http://localhost:${PORT}`);
  });
}

startServer();
