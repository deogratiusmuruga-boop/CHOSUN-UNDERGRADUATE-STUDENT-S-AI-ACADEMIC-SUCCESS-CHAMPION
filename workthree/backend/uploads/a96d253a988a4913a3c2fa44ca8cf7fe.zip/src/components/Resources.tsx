import React, { useState } from "react";
import { 
  BookOpen, 
  Search, 
  Plus, 
  FileText, 
  Award, 
  Download, 
  Filter,
  Check,
  ChevronRight,
  User,
  Calendar,
  X
} from "lucide-react";
import { AcademicResource } from "../types";

interface ResourcesProps {
  lang: "en" | "ko";
  t: (key: any) => string;
  resources: AcademicResource[];
  onAddResource: (newResource: any) => Promise<void>;
  onDownloadResource: (id: string) => Promise<void>;
}

export default function Resources({ lang, t, resources, onAddResource, onDownloadResource }: ResourcesProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("All");
  const [selectedType, setSelectedType] = useState("All");
  const [showAddModal, setShowAddModal] = useState(false);
  const [activeViewerResource, setActiveViewerResource] = useState<AcademicResource | null>(null);

  // Form states
  const [newTitle, setNewTitle] = useState("");
  const [newSubject, setNewSubject] = useState("Computer Science");
  const [newType, setNewType] = useState<"note" | "paper" | "guide">("note");
  const [newDescription, setNewDescription] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Filter logic
  const filteredResources = resources.filter(res => {
    const matchesSearch = res.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          res.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === "All" || res.subject === selectedSubject;
    const matchesType = selectedType === "All" || res.type === selectedType;
    return matchesSearch && matchesSubject && matchesType;
  });

  // Extract unique subjects
  const subjects = ["All", ...Array.from(new Set(resources.map(r => r.subject)))];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newSubject || !newContent) return;
    setSubmitting(true);

    try {
      await onAddResource({
        title: newTitle,
        subject: newSubject,
        type: newType,
        description: newDescription,
        content: newContent,
        author: newAuthor || (lang === "ko" ? "학생 파이오니어" : "Student Pioneer")
      });
      // Reset form
      setNewTitle("");
      setNewDescription("");
      setNewContent("");
      setNewAuthor("");
      setShowAddModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadClick = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation(); // Avoid opening the viewer
    await onDownloadResource(id);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="academic-resources-page">
      
      {/* Title Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <BookOpen className="text-blue-600" size={22} />
            {t("academicResourceHub")}
          </h1>
          <p className="text-xs text-slate-500">{t("academicResourceHubDesc")}</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Plus size={14} />
          {t("uploadResource")}
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <span className="absolute left-3 top-2.5 text-slate-400">
            <Search size={16} />
          </span>
          <input 
            type="text" 
            placeholder={t("searchResourcesPlaceholder")}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 shrink-0">
            <Filter size={12} className="text-slate-400" />
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("filters")}</span>
          </div>

          <select
            value={selectedSubject}
            onChange={e => setSelectedSubject(e.target.value)}
            className="text-xs px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 cursor-pointer text-slate-700"
          >
            {subjects.map(sub => (
              <option key={sub} value={sub}>
                {sub === "All" ? (lang === "ko" ? "모든 과목" : "All Subjects") : sub}
              </option>
            ))}
          </select>

          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className="text-xs px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 cursor-pointer text-slate-700"
          >
            <option value="All">{t("allFormats")}</option>
            <option value="note">{t("resTypeNote")}</option>
            <option value="paper">{t("resTypePaper")}</option>
            <option value="guide">{t("resTypeGuide")}</option>
          </select>
        </div>
      </div>

      {/* Resources Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map(res => (
          <div 
            key={res.id}
            onClick={() => setActiveViewerResource(res)}
            className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md hover:border-blue-400/60 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <span className={`px-2 py-0.5 rounded text-[9px] font-bold tracking-wide uppercase ${
                  res.type === 'note' 
                    ? 'bg-blue-50 text-blue-700' 
                    : res.type === 'paper'
                      ? 'bg-red-50 text-red-700'
                      : 'bg-amber-50 text-amber-700'
                }`}>
                  {res.type === 'note' ? t("resTypeNote") : res.type === 'paper' ? t("resTypePaper") : t("resTypeGuide")}
                </span>
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">{res.subject}</span>
              </div>

              <div className="space-y-1.5">
                <h3 className="font-bold text-slate-800 text-sm group-hover:text-blue-600 transition-colors leading-snug">
                  {res.title}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2">
                  {res.description}
                </p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1 text-slate-400 text-[10px] font-medium">
                <User size={12} />
                <span className="truncate max-w-[100px]">{res.author}</span>
              </div>

              <button
                onClick={(e) => handleDownloadClick(e, res.id)}
                className="px-2.5 py-1.5 bg-slate-50 group-hover:bg-blue-50 text-slate-500 group-hover:text-blue-600 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer hover:scale-105 shrink-0"
              >
                <Download size={11} />
                <span>{res.downloads}</span>
              </button>
            </div>
          </div>
        ))}

        {filteredResources.length === 0 && (
          <div className="col-span-full bg-white p-12 text-center rounded-2xl border border-dashed border-slate-200 space-y-2">
            <p className="text-slate-400 text-sm">{t("noResourcesFound")}</p>
            <button 
              onClick={() => { setSearchTerm(""); setSelectedSubject("All"); setSelectedType("All"); }}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              {t("resetSearch")}
            </button>
          </div>
        )}
      </div>

      {/* LIGHTBOX NOTE VIEWER MODAL */}
      {activeViewerResource && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl">
            {/* Header */}
            <div className="p-5 border-b border-slate-100 flex justify-between items-start">
              <div className="space-y-1">
                <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-[9px] font-bold uppercase">
                  {activeViewerResource.type === 'note' ? t("resTypeNote") : activeViewerResource.type === 'paper' ? t("resTypePaper") : t("resTypeGuide")}
                </span>
                <h3 className="font-bold text-slate-800 text-base">{activeViewerResource.title}</h3>
                <p className="text-[10px] text-slate-400">
                  {lang === "ko" ? "작성자:" : "By"} {activeViewerResource.author} • {activeViewerResource.date}
                </p>
              </div>
              <button 
                onClick={() => setActiveViewerResource(null)}
                className="p-1.5 hover:bg-slate-50 rounded-full text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Document Content */}
            <div className="p-6 overflow-y-auto space-y-4 flex-1">
              <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100/80">
                <p className="text-xs text-slate-600 italic leading-relaxed">
                  "{activeViewerResource.description}"
                </p>
              </div>

              {/* Styled document content mimicking markdown/code rendering */}
              <div className="p-5 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs whitespace-pre-wrap leading-relaxed shadow-inner border border-slate-800">
                {activeViewerResource.content}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-between items-center">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">{activeViewerResource.subject} Hub</span>
              <button
                onClick={async () => {
                  await onDownloadResource(activeViewerResource.id);
                  // Update current download count locally for UI syncing
                  setActiveViewerResource(prev => prev ? { ...prev, downloads: prev.downloads + 1 } : null);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Download size={13} />
                {t("downloadExportBtn")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UPLOAD NOTES / PAPERS MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-lg shadow-2xl flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <Plus size={16} className="text-blue-600" />
                {t("uploadAcademicMaterial")}
              </h3>
              <button 
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-slate-50 rounded-full text-slate-400 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto max-h-[70vh]">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("documentTitle")}</label>
                <input 
                  type="text" 
                  placeholder={lang === "ko" ? "예: 선형대수학 중간고사 족보 해설" : "e.g. Intro to Algorithms Practice midterm solutions"}
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  required
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("courseSubject")}</label>
                  <select
                    value={newSubject}
                    onChange={e => setNewSubject(e.target.value)}
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 text-slate-700"
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Physics">Physics</option>
                    <option value="Applied Sciences">Applied Sciences</option>
                    <option value="General Studies">General Studies</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("materialType")}</label>
                  <select
                    value={newType}
                    onChange={e => setNewType(e.target.value as any)}
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 text-slate-700"
                  >
                    <option value="note">{t("resTypeNote")}</option>
                    <option value="paper">{t("resTypePaper")}</option>
                    <option value="guide">{t("resTypeGuide")}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("contributorName")}</label>
                <input 
                  type="text" 
                  placeholder="e.g. Alex Rivera or Anonymous"
                  value={newAuthor}
                  onChange={e => setNewAuthor(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("shortDescription")}</label>
                <input 
                  type="text" 
                  placeholder={lang === "ko" ? "자료에서 다루는 주제가 무엇인가요?" : "What topics are covered in this notes sheet?"}
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("documentContent")}</label>
                <textarea 
                  rows={4}
                  placeholder={lang === "ko" ? "# 상세한 요약 노트, 공식, 답변 등을 작성해 주세요..." : "# Enter your detailed course notes, formulas, or answers..."}
                  value={newContent}
                  onChange={e => setNewContent(e.target.value)}
                  required
                  className="w-full text-xs p-3.5 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="w-1/2 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-500 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  {t("cancel")}
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-1/2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer flex items-center justify-center gap-1"
                >
                  {submitting && <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>}
                  {t("publishMaterial")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
