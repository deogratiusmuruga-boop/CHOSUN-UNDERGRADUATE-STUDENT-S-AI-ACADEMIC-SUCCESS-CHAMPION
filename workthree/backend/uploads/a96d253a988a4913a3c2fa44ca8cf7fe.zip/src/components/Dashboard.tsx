import React, { useState, useEffect } from "react";
import { 
  GraduationCap, 
  BookOpen, 
  Award, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  FileText, 
  ChevronRight, 
  ArrowUpRight, 
  Star, 
  Calendar,
  DollarSign
} from "lucide-react";
import { AcademicResource, Scholarship, StudentProject, StudyPlan } from "../types";

interface DashboardProps {
  lang: "en" | "ko";
  t: (key: any) => string;
  onNavigate: (tab: string) => void;
  resources: AcademicResource[];
  scholarships: Scholarship[];
  projects: StudentProject[];
  onGeneratePlan: (subject: string, current: string, target: string) => void;
  activePlan: StudyPlan | null;
}

export default function Dashboard({ 
  lang,
  t,
  onNavigate, 
  resources, 
  scholarships, 
  projects,
  onGeneratePlan,
  activePlan 
}: DashboardProps) {
  // GPA Tool State
  const [subject, setSubject] = useState("");
  const [currentGrade, setCurrentGrade] = useState("B");
  const [targetGpa, setTargetGpa] = useState("A");
  const [loadingPlan, setLoadingPlan] = useState(false);

  // Todo Items State with bilingual support
  const [todos, setTodos] = useState([
    { id: 1, textEn: "Revise Quantum Infinite Square Well equations", textKo: "양자 우물 상자 방정식 복습하기", completed: false, tagEn: "Physics", tagKo: "물리" },
    { id: 2, textEn: "Submit outline for Ada Lovelace Scholarship draft", textKo: "에이다 러브레이스 장학금 에세이 개요 제출", completed: true, tagEn: "Admin", tagKo: "행정" },
    { id: 3, textEn: "Read Prof. Gilbert's linear algebra guide", textKo: "길버트 교수의 선형대수학 가이드 정독", completed: false, tagEn: "Mathematics", tagKo: "수학" },
    { id: 4, textEn: "Review Evelyn's Distributed KV Store Go codebase", textKo: "에블린의 Go 분산 KV 저장소 코드베이스 리뷰", completed: false, tagEn: "Peer review", tagKo: "동료 리뷰" }
  ]);

  const handleToggleTodo = (id: number) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const handleGpaPlanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) return;
    setLoadingPlan(true);
    await onGeneratePlan(subject, currentGrade, targetGpa);
    setLoadingPlan(false);
    onNavigate("chat"); // Take them to chat where the active plan is shown!
  };

  return (
    <div className="space-y-8 animate-fade-in" id="dashboard-view">
      {/* Welcome Hero Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-8 text-white shadow-md border border-slate-800">
        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 opacity-10 pointer-events-none">
          <GraduationCap size={300} />
        </div>
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 rounded-full text-indigo-300 text-xs font-medium border border-indigo-500/30">
            <Sparkles size={12} className="animate-pulse" />
            {t("welcomeActive")}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold font-sans tracking-tight leading-tight">
            {t("welcomeTitle")}
          </h1>
          <p className="text-slate-300 text-sm md:text-base leading-relaxed">
            {t("welcomeDesc")}
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <button 
              onClick={() => onNavigate("chat")}
              className="px-5 py-2.5 bg-white text-slate-900 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              {t("consultAi")}
              <ChevronRight size={16} />
            </button>
            <button 
              onClick={() => onNavigate("resources")}
              className="px-5 py-2.5 bg-slate-800/80 hover:bg-slate-800 text-white rounded-lg text-sm font-semibold transition-all border border-slate-700/60 flex items-center gap-1.5 cursor-pointer"
            >
              {t("browseMaterials")}
              <BookOpen size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Quick Statistics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-sm flex items-center gap-4 hover:shadow-md transition-all">
          <div className="p-3 bg-indigo-50 rounded-lg text-indigo-600">
            <GraduationCap size={24} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t("currentStanding")}</p>
            <h3 className="text-2xl font-bold text-slate-800">3.82 GPA</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-sm flex items-center gap-4 hover:shadow-md transition-all">
          <div className="p-3 bg-emerald-50 rounded-lg text-emerald-600">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t("studyTime")}</p>
            <h3 className="text-2xl font-bold text-slate-800">18.5 {lang === "ko" ? "시간" : "hrs"} <span className="text-xs text-slate-400 font-normal">{t("hrsWk")}</span></h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-sm flex items-center gap-4 hover:shadow-md transition-all">
          <div className="p-3 bg-amber-50 rounded-lg text-amber-600">
            <Award size={24} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t("tabGrants")}</p>
            <h3 className="text-2xl font-bold text-slate-800">{scholarships.length} {t("tracked")}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-sm flex items-center gap-4 hover:shadow-md transition-all">
          <div className="p-3 bg-rose-50 rounded-lg text-rose-600">
            <BookOpen size={24} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t("peerPortfolios")}</p>
            <h3 className="text-2xl font-bold text-slate-800">{projects.length} {t("active")}</h3>
          </div>
        </div>
      </div>

      {/* Main Content Split: Planner & GPA Improvement Tool */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Tasks and Planner */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <CheckCircle2 className="text-indigo-600" size={20} />
                {t("dailyTasks")}
              </h2>
              <p className="text-xs text-slate-500">{t("stayOnTop")}</p>
            </div>
            <span className="text-xs font-semibold bg-indigo-50 text-indigo-600 px-2 py-1 rounded-full">
              {todos.filter(t => !t.completed).length} {t("remaining")}
            </span>
          </div>

          <div className="space-y-3">
            {todos.map(todo => (
              <div 
                key={todo.id} 
                className={`flex items-center justify-between p-3.5 rounded-lg border transition-all ${
                  todo.completed 
                    ? "bg-slate-50/50 border-slate-100 text-slate-400" 
                    : "bg-white border-slate-200/70 text-slate-700 hover:border-slate-300 shadow-xs"
                }`}
              >
                <div className="flex items-center gap-3">
                  <input 
                    type="checkbox"
                    checked={todo.completed}
                    onChange={() => handleToggleTodo(todo.id)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 transition-all cursor-pointer"
                  />
                  <span className={`text-sm ${todo.completed ? "line-through text-slate-400" : "font-medium"}`}>
                    {lang === "ko" ? todo.textKo : todo.textEn}
                  </span>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                  todo.completed 
                    ? "bg-slate-200 text-slate-500" 
                    : "bg-indigo-50 text-indigo-600"
                }`}>
                  {lang === "ko" ? todo.tagKo : todo.tagEn}
                </span>
              </div>
            ))}
          </div>

          {activePlan && (
            <div className="mt-4 p-4 bg-indigo-50/60 rounded-xl border border-indigo-100 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-indigo-800 uppercase tracking-wider">{t("activeStudyPlan")}</h4>
                <span className="text-[10px] font-bold bg-indigo-600 text-white px-2 py-0.5 rounded-full">{t("week1Focus")}</span>
              </div>
              <p className="text-sm font-semibold text-slate-800">{activePlan.subject} {t("tabOverview")}</p>
              <p className="text-xs text-slate-600">{activePlan.schedule[0]?.focus || "Reviewing foundational components"}</p>
              <button 
                onClick={() => onNavigate("chat")}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer pt-1"
              >
                {t("viewFullCalendar")}
              </button>
            </div>
          )}
        </div>

        {/* Right Column: GPA Improvement Plan Generator */}
        <div className="bg-gradient-to-b from-indigo-50/80 to-slate-50 p-6 rounded-xl border border-slate-200/80 shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Sparkles className="text-amber-500" size={20} />
              {t("gpaAccelerator")}
            </h2>
            <p className="text-xs text-slate-600">{t("generatePlanDesc")}</p>
          </div>

          <form onSubmit={handleGpaPlanSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">{t("targetSubject")}</label>
              <input 
                type="text" 
                placeholder={lang === "ko" ? "예: 선형대수학, 인공지능 기초" : "e.g. Advanced Calculus, Machine Learning"}
                value={subject}
                onChange={e => setSubject(e.target.value)}
                required
                className="w-full text-sm px-3.5 py-2.5 rounded-lg bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t("currentStanding")}</label>
                <select 
                  value={currentGrade}
                  onChange={e => setCurrentGrade(e.target.value)}
                  className="w-full text-sm px-3.5 py-2.5 rounded-lg bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="A">{t("gradeA")}</option>
                  <option value="B">{t("gradeB")}</option>
                  <option value="C">{t("gradeC")}</option>
                  <option value="D">{t("gradeD")}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t("targetStanding")}</label>
                <select 
                  value={targetGpa}
                  onChange={e => setTargetGpa(e.target.value)}
                  className="w-full text-sm px-3.5 py-2.5 rounded-lg bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="A+">A+ / 4.0</option>
                  <option value="A">A / 3.8</option>
                  <option value="A-">A- / 3.5</option>
                  <option value="B+">B+ / 3.2</option>
                </select>
              </div>
            </div>

            <button 
              type="submit" 
              disabled={loadingPlan}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {loadingPlan ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  {t("architectingPlan")}
                </>
              ) : (
                <>
                  <Sparkles size={16} />
                  {t("generateStudyPlanBtn")}
                </>
              )}
            </button>
          </form>

          {/* Educational Insight Card */}
          <div className="p-3.5 bg-white rounded-lg border border-slate-200/50 space-y-1.5">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <GraduationCap size={14} className="text-amber-500" />
              {t("studyTipTitle")}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed font-sans">
              {t("studyTipDesc")}
            </p>
          </div>
        </div>
      </div>

      {/* Featured Resources, Scholarships & Projects Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Latest Resources */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
              <FileText className="text-indigo-600" size={16} />
              {t("recentStudyFiles")}
            </h3>
            <button 
              onClick={() => onNavigate("resources")}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
            >
              {t("viewAll")}
            </button>
          </div>

          <div className="space-y-3">
            {resources.slice(0, 3).map(res => (
              <div 
                key={res.id} 
                onClick={() => onNavigate("resources")}
                className="group flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-all cursor-pointer border border-transparent hover:border-slate-100"
              >
                <div className="p-2 bg-slate-50 group-hover:bg-indigo-50 text-slate-600 group-hover:text-indigo-600 rounded-lg transition-colors">
                  <FileText size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-700 truncate">{res.title}</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">{res.subject} • {res.type === "note" ? t("resTypeNote") : res.type === "paper" ? t("resTypePaper") : t("resTypeGuide")}</p>
                </div>
                <ArrowUpRight size={14} className="text-slate-300 group-hover:text-slate-600 transition-colors shrink-0" />
              </div>
            ))}
          </div>
        </div>

        {/* Top Scholarships */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
              <span className="text-emerald-600 font-semibold text-lg">₩</span>
              {t("featuredFunding")}
            </h3>
            <button 
              onClick={() => onNavigate("scholarships")}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
            >
              {t("viewAll")}
            </button>
          </div>

          <div className="space-y-3">
            {scholarships.slice(0, 3).map(sch => (
              <div 
                key={sch.id} 
                onClick={() => onNavigate("scholarships")}
                className="group flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-all cursor-pointer border border-transparent hover:border-slate-100"
              >
                <div className="p-2 bg-slate-50 group-hover:bg-emerald-50 text-slate-600 group-hover:text-emerald-600 rounded-lg transition-colors">
                  <Award size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-700 truncate">{sch.name}</h4>
                  <p className="text-[10px] text-emerald-600 font-semibold mt-0.5">{sch.amount}</p>
                </div>
                <ArrowUpRight size={14} className="text-slate-300 group-hover:text-slate-600 transition-colors shrink-0" />
              </div>
            ))}
          </div>
        </div>

        {/* Star Projects */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
              <Star className="text-amber-500 fill-amber-500" size={16} />
              {t("peerPortfolios")}
            </h3>
            <button 
              onClick={() => onNavigate("projects")}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
            >
              {t("viewAll")}
            </button>
          </div>

          <div className="space-y-3">
            {projects.slice(0, 3).map(proj => (
              <div 
                key={proj.id} 
                onClick={() => onNavigate("projects")}
                className="group flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-all cursor-pointer border border-transparent hover:border-slate-100"
              >
                <div className="p-2 bg-slate-50 group-hover:bg-amber-50 text-slate-600 group-hover:text-amber-500 rounded-lg transition-colors">
                  <Star size={16} className="group-hover:fill-amber-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-700 truncate">{proj.title}</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">{lang === "ko" ? "작성자:" : "by"} {proj.author} • {proj.stars} ★</p>
                </div>
                <ArrowUpRight size={14} className="text-slate-300 group-hover:text-slate-600 transition-colors shrink-0" />
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
