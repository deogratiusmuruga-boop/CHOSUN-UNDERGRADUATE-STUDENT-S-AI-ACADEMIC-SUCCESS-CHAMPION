import React, { useState } from "react";
import { 
  FolderGit2, 
  Search, 
  Plus, 
  Star, 
  Code, 
  Sparkles, 
  Globe, 
  Heart,
  MessageSquare,
  Cpu,
  RefreshCw,
  X,
  PlusCircle,
  TrendingUp
} from "lucide-react";
import { StudentProject } from "../types";

interface ProjectsProps {
  lang: "en" | "ko";
  t: (key: any) => string;
  projects: StudentProject[];
  onAddProject: (newProj: any) => Promise<void>;
  onStarProject: (id: string) => Promise<void>;
  onAiReviewProject: (id: string) => Promise<string[]>;
}

export default function Projects({ lang, t, projects, onAddProject, onStarProject, onAiReviewProject }: ProjectsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [showAddModal, setShowAddModal] = useState(false);
  const [reviewingId, setReviewingId] = useState<string | null>(null);

  // Form states
  const [newTitle, setNewTitle] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newSubject, setNewSubject] = useState("Computer Science");
  const [newCategory, setNewCategory] = useState<'research' | 'software' | 'design' | 'engineering' | 'business'>("software");
  const [newTechStack, setNewTechStack] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [newCodeUrl, setNewCodeUrl] = useState("");
  const [newDemoUrl, setNewDemoUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Filters logic
  const filteredProjects = projects.filter(proj => {
    const matchesSearch = proj.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          proj.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          proj.techStack.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === "All" || proj.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { value: "All", label: lang === "ko" ? "모든 분야" : "All Sectors" },
    { value: "software", label: lang === "ko" ? "소프트웨어 시스템" : "Software Systems" },
    { value: "engineering", label: lang === "ko" ? "기계 및 하드웨어" : "Mechanical & Hardware" },
    { value: "research", label: lang === "ko" ? "학술 연구" : "Academic Research" },
    { value: "design", label: lang === "ko" ? "사용자 경험 & UI" : "User Experience & UI" },
    { value: "business", label: lang === "ko" ? "벤처 창업" : "Venture Pitches" }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDescription || !newSubject) return;
    setSubmitting(true);

    try {
      // Split tech stack by comma and clean up spaces
      const tags = newTechStack ? newTechStack.split(",").map(t => t.trim()).filter(Boolean) : [];
      await onAddProject({
        title: newTitle,
        description: newDescription,
        subject: newSubject,
        category: newCategory,
        techStack: tags,
        author: newAuthor || (lang === "ko" ? "학생 파이오니어" : "Student Pioneer"),
        codeUrl: newCodeUrl || undefined,
        demoUrl: newDemoUrl || undefined
      });
      // Reset form
      setNewTitle("");
      setNewDescription("");
      setNewSubject("Computer Science");
      setNewCategory("software");
      setNewTechStack("");
      setNewAuthor("");
      setNewCodeUrl("");
      setNewDemoUrl("");
      setShowAddModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAiReview = async (id: string) => {
    setReviewingId(id);
    try {
      await onAiReviewProject(id);
    } catch (err) {
      alert(lang === "ko" ? "동료 리뷰 서비스가 현재 혼잡합니다." : "Peer review service currently busy.");
    } finally {
      setReviewingId(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="student-projects-page">
      
      {/* Title Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <FolderGit2 className="text-blue-600" size={22} />
            {t("portfoliosRegistry")}
          </h1>
          <p className="text-xs text-slate-500">{t("portfoliosDesc")}</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Plus size={14} />
          {t("shareArtifact")}
        </button>
      </div>

      {/* Grid Filter Options */}
      <div className="flex flex-wrap gap-1.5 pb-2">
        {categories.map(cat => (
          <button
            key={cat.value}
            onClick={() => setSelectedCategory(cat.value)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === cat.value
                ? "bg-blue-600 text-white shadow-xs"
                : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Search Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full">
          <span className="absolute left-3 top-2.5 text-slate-400">
            <Search size={16} />
          </span>
          <input 
            type="text" 
            placeholder={lang === "ko" ? "프로젝트 제목, 설명 검색어, 또는 기술 스택 태그로 검색..." : "Search projects by title, description keywords, or engineering stack tags..."}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-600"
          />
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredProjects.map(proj => (
          <div 
            key={proj.id}
            className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between space-y-5 hover:border-slate-300 hover:shadow-sm transition-all"
          >
            <div className="space-y-4">
              <div className="flex justify-between items-start gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {proj.category === 'software' ? t("softwareEngine") : proj.category === 'engineering' ? t("physicalHardware") : proj.category === 'research' ? (lang === "ko" ? "학술 연구" : "Academic Research") : proj.category === 'design' ? t("industrialDesign") : (lang === "ko" ? "벤처 창업" : "Venture Pitch")}
                  </span>
                  <h3 className="font-bold text-slate-800 text-base leading-snug">
                    {proj.title}
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    {lang === "ko" ? "작성자:" : "Author:"} {proj.author} • {lang === "ko" ? "전공/과목:" : "Course:"} {proj.subject}
                  </p>
                </div>

                <button 
                  onClick={() => onStarProject(proj.id)}
                  className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-100 text-amber-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer hover:scale-105"
                  title="Star Project"
                >
                  <Star size={13} className="fill-amber-500 text-amber-500" />
                  <span>{proj.stars}</span>
                </button>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                {proj.description}
              </p>

              {/* Tech Stack badging */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {proj.techStack.map((tech, idx) => (
                  <span 
                    key={idx}
                    className="px-2 py-1 bg-slate-50 border border-slate-200/60 rounded-md text-[10px] font-semibold text-slate-600"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* External Links & Live Llama Feedback Area */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  {proj.codeUrl && (
                    <a 
                      href={proj.codeUrl} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                    >
                      <Code size={13} />
                      {t("viewRepo")}
                    </a>
                  )}
                  {proj.demoUrl && (
                    <a 
                      href={proj.demoUrl} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer ml-2"
                    >
                      <Globe size={13} />
                      {t("viewDemo")}
                    </a>
                  )}
                </div>

                <button
                  onClick={() => handleAiReview(proj.id)}
                  disabled={reviewingId === proj.id}
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 shadow-xs hover:shadow-md cursor-pointer disabled:opacity-75"
                >
                  {reviewingId === proj.id ? (
                    <>
                      <RefreshCw size={11} className="animate-spin" />
                      {t("requestingReview")}
                    </>
                  ) : (
                    <>
                      <Sparkles size={11} />
                      {t("requestReviewBtn")}
                    </>
                  )}
                </button>
              </div>

              {/* Review feedback panel */}
              {proj.feedback && proj.feedback.length > 0 && (
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 space-y-2.5">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <MessageSquare size={12} />
                    {lang === "ko" ? `과거 리뷰 목록 (${proj.feedback.length})` : `Historical Reviews (${proj.feedback.length})`}
                  </p>
                  <div className="space-y-2 max-h-[140px] overflow-y-auto">
                    {proj.feedback.map((f, idx) => {
                      const isLlama = f.includes("Llama AI Assistant") || f.includes("Llama AI Mentor") || f.includes("Llama") || f.includes("조선 AI");
                      return (
                        <div 
                          key={idx} 
                          className={`p-3 rounded-lg text-xs leading-relaxed border ${
                            isLlama 
                              ? 'bg-amber-50/50 border-amber-100 text-amber-900 font-sans' 
                              : 'bg-white border-slate-100 text-slate-600'
                          }`}
                        >
                          {f}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}

        {filteredProjects.length === 0 && (
          <div className="col-span-full bg-white p-12 text-center rounded-2xl border border-dashed border-slate-200 space-y-2">
            <p className="text-slate-400 text-xs">
              {lang === "ko" ? "조회 기준에 부합하는 프로젝트 포트폴리오가 없습니다." : "No project submissions found matching the criteria."}
            </p>
            <button 
              onClick={() => { setSearchTerm(""); setSelectedCategory("All"); }}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              {lang === "ko" ? "필터 초기화" : "Reset Filters"}
            </button>
          </div>
        )}
      </div>

      {/* PUBLISH NEW PROJECT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-lg shadow-2xl flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <Plus size={16} className="text-blue-600" />
                {t("shareArtifact")}
              </h3>
              <button 
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-slate-50 rounded-full text-slate-400 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto max-h-[70vh]">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("projectTitle")}</label>
                <input 
                  type="text" 
                  placeholder={lang === "ko" ? "예: Raft 합의 알고리즘을 사용한 분산 키-값 저장소" : "e.g. Distributed Key-Value Store with Raft Consensus"}
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  required
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("description")}</label>
                <textarea 
                  rows={3}
                  placeholder={lang === "ko" ? "아키텍처 설계 세부 정보, 해결한 제한 사항 및 핵심 결과를 설명해 주세요..." : "Explain the architectural engineering details, constraints solved, and core results..."}
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  required
                  className="w-full text-xs p-3.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("projectMajor")}</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Computer Science, Physics"
                    value={newSubject}
                    onChange={e => setNewSubject(e.target.value)}
                    required
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none text-slate-700"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("projectCategory")}</label>
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value as any)}
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none text-slate-700"
                  >
                    <option value="software">{t("softwareEngine")}</option>
                    <option value="engineering">{t("physicalHardware")}</option>
                    <option value="research">{lang === "ko" ? "학술 연구" : "Academic Research"}</option>
                    <option value="design">{t("industrialDesign")}</option>
                    <option value="business">{lang === "ko" ? "벤처 창업" : "Venture Pitch"}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("techStackComma")}</label>
                <input 
                  type="text" 
                  placeholder="e.g. Go, gRPC, Docker, React, Python"
                  value={newTechStack}
                  onChange={e => setNewTechStack(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{lang === "ko" ? "작성자 이름 / 팀 대표" : "Author Name / Team Leads"}</label>
                <input 
                  type="text" 
                  placeholder="e.g. Alex Rivera or Team Ada"
                  value={newAuthor}
                  onChange={e => setNewAuthor(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("repositoryUrl")}</label>
                  <input 
                    type="url" 
                    placeholder="https://github.com/..."
                    value={newCodeUrl}
                    onChange={e => setNewCodeUrl(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("liveDemoUrl")}</label>
                  <input 
                    type="url" 
                    placeholder="https://demo.domain.com"
                    value={newDemoUrl}
                    onChange={e => setNewDemoUrl(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="w-1/2 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-500 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  {t("cancel")}
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-1/2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer flex items-center justify-center gap-1"
                >
                  {submitting && <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>}
                  {t("publishPortfolio")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
