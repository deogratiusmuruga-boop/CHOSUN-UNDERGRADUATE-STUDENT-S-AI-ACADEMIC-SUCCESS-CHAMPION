import React, { useState } from "react";
import { 
  Calendar, 
  Sparkles, 
  Layers, 
  Award, 
  HelpCircle, 
  Brain, 
  CheckCircle, 
  AlertCircle 
} from "lucide-react";
import { StudyPlan, GeneratedQuiz } from "../types";

interface PlannerAndQuizProps {
  lang: "en" | "ko";
  t: (key: any) => string;
  activePlan: StudyPlan | null;
  onSetActivePlan: (plan: StudyPlan) => void;
}

export default function PlannerAndQuiz({ lang, t, activePlan, onSetActivePlan }: PlannerAndQuizProps) {
  const [activeSubTab, setActiveSubTab] = useState<'planner' | 'quiz'>('planner');

  // Study Planner Form State
  const [planSubject, setPlanSubject] = useState("");
  const [planCurrentGrade, setPlanCurrentGrade] = useState("B");
  const [planTargetGpa, setPlanTargetGpa] = useState("A");
  const [planWeeks, setPlanWeeks] = useState(4);
  const [planNotes, setPlanNotes] = useState("");
  const [generatingPlan, setGeneratingPlan] = useState(false);

  // Quiz State
  const [quizSubject, setQuizSubject] = useState("");
  const [quizTopics, setQuizTopics] = useState("");
  const [quizDifficulty, setQuizDifficulty] = useState("Medium");
  const [currentQuiz, setCurrentQuiz] = useState<GeneratedQuiz | null>(null);
  const [generatingQuiz, setGeneratingQuiz] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [submittedQuiz, setSubmittedQuiz] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Generate study plan
  const handleGenerateStudyPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planSubject.trim()) return;
    setGeneratingPlan(true);

    try {
      const response = await fetch("/api/chatbot/study-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: planSubject,
          currentGrade: planCurrentGrade,
          targetGpa: planTargetGpa,
          durationWeeks: planWeeks,
          notesText: planNotes
        })
      });

      const data = await response.json();
      if (response.ok) {
        onSetActivePlan(data);
      } else {
        throw new Error(data.error || "Study plan generation failed.");
      }
    } catch (error: any) {
      alert((lang === "ko" ? "학습 계획 생성 중 오류 발생: " : "Error generating study plan: ") + error.message);
    } finally {
      setGeneratingPlan(false);
    }
  };

  // Generate quiz
  const handleGenerateQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quizSubject.trim()) return;
    setGeneratingQuiz(true);
    setCurrentQuiz(null);
    setSelectedAnswers({});
    setSubmittedQuiz(false);

    try {
      const response = await fetch("/api/chatbot/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: quizSubject,
          topics: quizTopics,
          difficulty: quizDifficulty
        })
      });

      const data = await response.json();
      if (response.ok) {
        setCurrentQuiz(data);
      } else {
        throw new Error(data.error || "Quiz generation failed.");
      }
    } catch (error: any) {
      alert((lang === "ko" ? "퀴즈 생성 중 오류 발생: " : "Error generating quiz: ") + error.message);
    } finally {
      setGeneratingQuiz(false);
    }
  };

  const handleSelectAnswer = (qIndex: number, optionIndex: number) => {
    if (submittedQuiz) return;
    setSelectedAnswers(prev => ({ ...prev, [qIndex]: optionIndex }));
  };

  const handleSubmitQuiz = () => {
    if (!currentQuiz) return;
    let score = 0;
    currentQuiz.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        score++;
      }
    });
    setQuizScore(score);
    setSubmittedQuiz(true);
  };

  return (
    <div className="space-y-6" id="planner-quiz-container">
      
      {/* Sub tabs inside the panel */}
      <div className="flex gap-2 p-1 bg-slate-100 rounded-lg max-w-sm">
        <button
          onClick={() => setActiveSubTab('planner')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
            activeSubTab === 'planner'
              ? "bg-white text-blue-600 shadow-xs"
              : "text-slate-600 hover:text-slate-800"
          }`}
        >
          <Calendar size={13} className="inline mr-1" />
          {lang === "ko" ? "학습 계획 플래너" : "Study Planner"}
        </button>
        <button
          onClick={() => setActiveSubTab('quiz')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
            activeSubTab === 'quiz'
              ? "bg-white text-blue-600 shadow-xs"
              : "text-slate-600 hover:text-slate-800"
          }`}
        >
          <HelpCircle size={13} className="inline mr-1" />
          {lang === "ko" ? "스마트 퀴즈" : "Smart Quizzer"}
        </button>
      </div>

      {/* PLANNER PANEL */}
      {activeSubTab === 'planner' && (
        <div className="space-y-6 animate-fade-in" id="planner-sub-panel">
          <div className="space-y-1.5">
            <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
              <Calendar className="text-blue-600" size={18} />
              {t("plannerQuizHeader")}
            </h2>
            <p className="text-xs text-slate-500">
              {t("plannerQuizDesc")}
            </p>
          </div>

          <form onSubmit={handleGenerateStudyPlan} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-1 space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("courseSubjectLabel")}</label>
              <input 
                type="text"
                placeholder={lang === "ko" ? "예: 알고리즘 설계, 선형대수학" : "e.g. Distributed Databases, Linear Algebra"}
                value={planSubject}
                onChange={e => setPlanSubject(e.target.value)}
                required
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-1 space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("durationWeeksLabel")}</label>
              <input 
                type="number"
                min={2}
                max={12}
                value={planWeeks}
                onChange={e => setPlanWeeks(Number(e.target.value))}
                required
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("currentStandingLabel")}</label>
              <select 
                value={planCurrentGrade}
                onChange={e => setPlanCurrentGrade(e.target.value)}
                className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none cursor-pointer text-slate-700"
              >
                <option value="A">{lang === "ko" ? "A 학점 (유지)" : "Grade A (Maintaining)"}</option>
                <option value="B">{lang === "ko" ? "B 학점 (향상)" : "Grade B (Improving)"}</option>
                <option value="C">{lang === "ko" ? "C 학점 (갭 보완)" : "Grade C (Targeting Gap)"}</option>
                <option value="D">{lang === "ko" ? "D 학점 (집중 보완)" : "Grade D (Intensive Remediation)"}</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("targetGpaLabel")}</label>
              <select 
                value={planTargetGpa}
                onChange={e => setPlanTargetGpa(e.target.value)}
                className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none cursor-pointer text-slate-700"
              >
                <option value="A+">{lang === "ko" ? "A+ 학점 / 4.0 Standing" : "A+ / 4.0 Standing"}</option>
                <option value="A">{lang === "ko" ? "A 학점 / 3.8 Standing" : "A / 3.8 Standing"}</option>
                <option value="A-">{lang === "ko" ? "A- 학점 / 3.5 Standing" : "A- / 3.5 Standing"}</option>
                <option value="B+">{lang === "ko" ? "B+ 학점 / 3.2 Standing" : "B+ / 3.2 Standing"}</option>
              </select>
            </div>

            <div className="sm:col-span-2 space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("syllabusContextLabel")}</label>
              <textarea 
                rows={2}
                placeholder={t("syllabusPlaceholder")}
                value={planNotes}
                onChange={e => setPlanNotes(e.target.value)}
                className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none font-sans"
              />
            </div>

            <div className="sm:col-span-2 pt-1">
              <button 
                type="submit"
                disabled={generatingPlan}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-70"
              >
                {generatingPlan ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    {t("architectingPlanBtn")}
                  </>
                ) : (
                  <>
                    <Sparkles size={14} />
                    {t("generatePlanBtn")}
                  </>
                )}
              </button>
            </div>
          </form>

          {activePlan && (
            <div className="space-y-5 animate-fade-in border-t border-slate-150 pt-5">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-bold text-slate-800">
                    {t("activePlanHeader")}: {activePlan.subject}
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    {lang === "ko" ? "목표 등급:" : "Target Standing:"} {activePlan.targetGpa} • {lang === "ko" ? "수강 기간:" : "Duration:"} {activePlan.durationWeeks} {lang === "ko" ? "주" : "Weeks"}
                  </p>
                </div>
                <span className="px-2.5 py-1 bg-green-50 text-green-700 border border-green-100 rounded-full text-[9px] font-bold uppercase tracking-wide">
                  {t("activeSync")}
                </span>
              </div>

              <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200/50 space-y-2">
                <h4 className="text-xs font-bold text-amber-800 flex items-center gap-1">
                  <Award size={14} />
                  {t("aiStrategicTips")}
                </h4>
                <ul className="space-y-1.5">
                  {activePlan.gpaTips.map((tip, idx) => (
                    <li key={idx} className="text-xs text-amber-900 leading-relaxed flex items-start gap-1.5">
                      <span className="text-amber-500 shrink-0 select-none font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {activePlan.schedule.map((weekItem) => (
                  <div 
                    key={weekItem.week}
                    className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-300 transition-colors shadow-xs space-y-3"
                  >
                    <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                      <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                        {lang === "ko" ? `${weekItem.week}주차` : `Week ${weekItem.week}`}
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                        <Layers size={10} /> {t("focusBlock")}
                      </span>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">{weekItem.focus}</h4>
                    </div>
                    <ul className="space-y-1.5">
                      {weekItem.tasks.map((task, tIdx) => (
                        <li key={tIdx} className="text-xs text-slate-600 flex items-start gap-1.5">
                          <span className="text-blue-500 font-bold shrink-0 mt-0.5">✓</span>
                          <span className="leading-tight">{task}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* QUIZZER PANEL */}
      {activeSubTab === 'quiz' && (
        <div className="space-y-6 animate-fade-in" id="quiz-sub-panel">
          <div className="space-y-1.5">
            <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
              <HelpCircle className="text-blue-600" size={18} />
              {t("quizzerHeader")}
            </h2>
            <p className="text-xs text-slate-500">
              {t("quizzerDesc")}
            </p>
          </div>

          <form onSubmit={handleGenerateQuiz} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("courseSubjectLabel")}</label>
              <input 
                type="text"
                placeholder={lang === "ko" ? "예: 양자역학, 알고리즘 분석" : "e.g. Quantum Mechanics, Algorithms"}
                value={quizSubject}
                onChange={e => setQuizSubject(e.target.value)}
                required
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("subTopicsLabel")}</label>
              <input 
                type="text"
                placeholder={lang === "ko" ? "예: 슈뢰딩거 우물, 동적 계획법" : "e.g. Schrodinger Well, Dynamic Programming"}
                value={quizTopics}
                onChange={e => setQuizTopics(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t("difficultyLabel")}</label>
              <select 
                value={quizDifficulty}
                onChange={e => setQuizDifficulty(e.target.value)}
                className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/15 focus:border-blue-600 focus:outline-none cursor-pointer text-slate-700"
              >
                <option value="Easy">{t("difficultyEasy")}</option>
                <option value="Medium">{t("difficultyMedium")}</option>
                <option value="Hard">{t("difficultyHard")}</option>
              </select>
            </div>

            <div className="sm:col-span-3 pt-1">
              <button 
                type="submit"
                disabled={generatingQuiz}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-70"
              >
                {generatingQuiz ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    {t("generatingQuizBtn")}
                  </>
                ) : (
                  <>
                    <Brain size={14} />
                    {t("generateQuizBtn")}
                  </>
                )}
              </button>
            </div>
          </form>

          {currentQuiz && (
            <div className="space-y-6 animate-fade-in border-t border-slate-150 pt-5">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-bold text-slate-800">{currentQuiz.title}</h3>
                  <p className="text-[10px] text-slate-400">{lang === "ko" ? "과목:" : "Subject:"} {currentQuiz.subject}</p>
                </div>
                {submittedQuiz && (
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    quizScore === currentQuiz.questions.length 
                      ? 'bg-green-100 text-green-800' 
                      : quizScore > 0 
                        ? 'bg-amber-100 text-amber-800' 
                        : 'bg-rose-100 text-rose-800'
                  }`}>
                    {t("gradeScore")}: {quizScore} / {currentQuiz.questions.length}
                  </span>
                )}
              </div>

              <div className="space-y-5">
                {currentQuiz.questions.map((q, qIdx) => (
                  <div key={qIdx} className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                    <h4 className="text-xs font-bold text-slate-800 flex items-start gap-1.5 leading-relaxed">
                      <span className="text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded text-[10px] select-none font-mono">Q{qIdx+1}</span>
                      <span>{q.questionText}</span>
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {q.options.map((opt, oIdx) => {
                        const isSelected = selectedAnswers[qIdx] === oIdx;
                        const isCorrect = q.correctIndex === oIdx;
                        
                        let btnStyle = "bg-white border-slate-200 hover:bg-slate-50 text-slate-700";
                        if (isSelected) {
                          btnStyle = "bg-blue-50 border-blue-600 text-blue-900 font-semibold";
                        }
                        if (submittedQuiz) {
                          if (isCorrect) {
                            btnStyle = "bg-green-50 border-green-600 text-green-900 font-bold";
                          } else if (isSelected) {
                            btnStyle = "bg-red-50 border-red-600 text-red-900";
                          } else {
                            btnStyle = "bg-white border-slate-250 text-slate-400 opacity-60";
                          }
                        }

                        return (
                          <button
                            key={oIdx}
                            type="button"
                            onClick={() => handleSelectAnswer(qIdx, oIdx)}
                            disabled={submittedQuiz}
                            className={`text-left text-xs p-3.5 rounded-lg border transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
                          >
                            <span>{opt}</span>
                            {submittedQuiz && isCorrect && <CheckCircle className="text-green-600 shrink-0" size={14} />}
                            {submittedQuiz && isSelected && !isCorrect && <AlertCircle className="text-red-500 shrink-0" size={14} />}
                          </button>
                        );
                      })}
                    </div>

                    {submittedQuiz && (
                      <div className="p-3.5 bg-blue-50/70 text-blue-900 border border-blue-100 rounded-lg text-xs leading-relaxed space-y-1">
                        <p className="font-bold flex items-center gap-1">
                          <Brain size={12} className="text-blue-600" />
                          {t("explanationLabel")}:
                        </p>
                        <p className="text-slate-700 font-sans">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {!submittedQuiz ? (
                <button
                  type="button"
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(selectedAnswers).length < currentQuiz.questions.length}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer text-center"
                >
                  {t("instantGradingBtn")}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setCurrentQuiz(null);
                    setSelectedAnswers({});
                    setSubmittedQuiz(false);
                  }}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer text-center"
                >
                  {t("tryAnotherQuizBtn")}
                </button>
              )}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
