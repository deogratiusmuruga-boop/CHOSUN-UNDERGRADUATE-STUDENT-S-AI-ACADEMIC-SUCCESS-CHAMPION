import React, { useState } from "react";
import { 
  Award, 
  Search, 
  Plus, 
  DollarSign, 
  Calendar, 
  FileText, 
  ExternalLink,
  Filter,
  CheckCircle,
  X
} from "lucide-react";
import { Scholarship } from "../types";

interface ScholarshipsProps {
  lang: "en" | "ko";
  t: (key: any) => string;
  scholarships: Scholarship[];
  onAddScholarship: (newSch: any) => Promise<void>;
}

export default function Scholarships({ lang, t, scholarships, onAddScholarship }: ScholarshipsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newAmount, setNewAmount] = useState("");
  const [newEligibility, setNewEligibility] = useState("");
  const [newDeadline, setNewDeadline] = useState("");
  const [newCategory, setNewCategory] = useState<'merit' | 'financial' | 'international' | 'minority' | 'general'>("merit");
  const [newLink, setNewLink] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Filters logic
  const filteredScholarships = scholarships.filter(sch => {
    const matchesSearch = sch.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          sch.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          sch.eligibility.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || sch.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { value: "All", label: lang === "ko" ? "모든 지원금" : "All Funding" },
    { value: "merit", label: lang === "ko" ? "성적 우수" : "Merit-Based" },
    { value: "financial", label: lang === "ko" ? "재정 지원" : "Financial Need" },
    { value: "international", label: lang === "ko" ? "유학생 지원" : "International Students" },
    { value: "minority", label: lang === "ko" ? "소외 계층" : "Underrepresented Groups" },
    { value: "general", label: lang === "ko" ? "일반 학술" : "General Awards" }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newAmount || !newDeadline) return;
    setSubmitting(true);

    try {
      await onAddScholarship({
        name: newName,
        description: newDescription,
        amount: newAmount.startsWith("₩") ? newAmount : `₩${newAmount}`,
        eligibility: newEligibility,
        deadline: newDeadline,
        category: newCategory,
        link: newLink || "https://example.edu/scholarships"
      });
      // Reset form
      setNewName("");
      setNewDescription("");
      setNewAmount("");
      setNewEligibility("");
      setNewDeadline("");
      setNewCategory("merit");
      setNewLink("");
      setShowAddModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="scholarships-page">
      
      {/* Title Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <Award className="text-blue-600" size={22} />
            {t("scholarshipsRegistry")}
          </h1>
          <p className="text-xs text-slate-500">{t("scholarshipsDesc")}</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Plus size={14} />
          {t("addedListings")}
        </button>
      </div>

      {/* Categories & Filter Pills */}
      <div className="flex flex-wrap gap-1.5 pb-2">
        {categories.map(cat => (
          <button
            key={cat.value}
            onClick={() => setSelectedCategory(cat.value)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === cat.value
                ? "bg-blue-600 text-white shadow-xs"
                : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full">
          <span className="absolute left-3 top-2.5 text-slate-400">
            <Search size={16} />
          </span>
          <input 
            type="text" 
            placeholder={lang === "ko" ? "장학금 명칭, 자격 요건, 기준 등으로 검색..." : "Search matching scholarships, requirements, eligibility rules..."}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-600"
          />
        </div>
      </div>

      {/* Scholarships List */}
      <div className="space-y-4">
        {filteredScholarships.map(sch => (
          <div 
            key={sch.id}
            className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col md:flex-row gap-6 justify-between items-start md:items-center"
          >
            <div className="space-y-3 flex-1">
              <div className="flex flex-wrap gap-2 items-center">
                <span className={`px-2 py-0.5 rounded text-[9px] font-bold tracking-wide uppercase ${
                  sch.category === 'merit' 
                    ? 'bg-blue-50 text-blue-700' 
                    : sch.category === 'financial'
                      ? 'bg-emerald-50 text-emerald-700'
                      : sch.category === 'international'
                        ? 'bg-purple-50 text-purple-700'
                        : sch.category === 'minority'
                          ? 'bg-indigo-50 text-indigo-700'
                          : 'bg-slate-100 text-slate-700'
                }`}>
                  {sch.category === 'merit' ? t("meritBased") : sch.category === 'financial' ? t("needBased") : sch.category === 'international' ? (lang === "ko" ? "유학생 지원" : "Global Fellowship") : sch.category === 'minority' ? t("underrepresented") : t("generalAcademic")}
                </span>

                <span className="text-slate-300 select-none">•</span>

                <p className="text-[10px] text-slate-400 font-semibold flex items-center gap-1">
                  <Calendar size={12} />
                  {lang === "ko" ? "마감일" : "Deadline"}: {sch.deadline}
                </p>
              </div>

              <div className="space-y-1.5">
                <h3 className="font-bold text-slate-800 text-base leading-tight">
                  {sch.name}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                  {sch.description}
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex flex-wrap items-center gap-2.5 text-xs">
                <span className="font-bold text-slate-700">{lang === "ko" ? "지원 요건:" : "Minimum Criteria:"}</span>
                <span className="text-slate-600 font-sans">{sch.eligibility}</span>
              </div>
            </div>

            <div className="flex flex-col items-start md:items-end gap-3 shrink-0 w-full md:w-auto md:border-l md:border-slate-100 md:pl-6">
              <div className="space-y-0.5">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider md:text-right">{t("financialAwards")}</p>
                <p className="text-xl font-bold text-emerald-600 flex items-center gap-0.5">
                  <span className="text-lg font-bold">₩</span>
                  {sch.amount.replace('$', '').replace('₩', '').trim()}
                </p>
              </div>

              <a 
                href={sch.link} 
                target="_blank" 
                rel="noreferrer"
                className="w-full md:w-auto px-4 py-2 bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 border border-blue-100/50 hover:border-blue-600 cursor-pointer"
              >
                {t("applyNow")}
                <ExternalLink size={12} />
              </a>
            </div>
          </div>
        ))}

        {filteredScholarships.length === 0 && (
          <div className="bg-white p-12 text-center rounded-2xl border border-dashed border-slate-200 space-y-2">
            <p className="text-slate-400 text-xs">{lang === "ko" ? "조건에 맞는 활성 장학 프로그램이 없습니다." : "No active programs found matching the filters."}</p>
            <button 
              onClick={() => { setSearchTerm(""); setSelectedCategory("All"); }}
              className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
            >
              {lang === "ko" ? "필터 초기화" : "Reset Search Filter"}
            </button>
          </div>
        )}
      </div>

      {/* REGISTER NEW SCHOLARSHIP MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-lg shadow-2xl flex flex-col">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <Plus size={16} className="text-blue-600" />
                {t("addedListings")}
              </h3>
              <button 
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-slate-50 rounded-full text-slate-400 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto max-h-[70vh]">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("grantName")}</label>
                <input 
                  type="text" 
                  placeholder={lang === "ko" ? "예: 조선학부 차세대 AI 인재 펠로우십" : "e.g. Next-Gen AI Innovators Fellowship"}
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  required
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("description")}</label>
                <textarea 
                  rows={2}
                  placeholder={lang === "ko" ? "장학금의 목적, 혜택, 후원 재단 정보를 간략히 작성해 주세요..." : "Describe the objective, benefits, and sponsor behind this grant..."}
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("grantAmount")}</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 1,500,000"
                    value={newAmount}
                    onChange={e => setNewAmount(e.target.value)}
                    required
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("deadline")}</label>
                  <input 
                    type="date" 
                    value={newDeadline}
                    onChange={e => setNewDeadline(e.target.value)}
                    required
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("filterCategory")}</label>
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value as any)}
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 text-slate-700"
                  >
                    <option value="merit">{t("meritBased")}</option>
                    <option value="financial">{t("needBased")}</option>
                    <option value="international">{lang === "ko" ? "유학생 지원" : "International Students"}</option>
                    <option value="minority">{t("underrepresented")}</option>
                    <option value="general">{t("generalAcademic")}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t("listingLink")}</label>
                  <input 
                    type="url" 
                    placeholder="https://apply.domain.com"
                    value={newLink}
                    onChange={e => setNewLink(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">{t("eligibilityCriteria")}</label>
                <input 
                  type="text" 
                  placeholder={lang === "ko" ? "예: 컴퓨터공학 전공생, 직전 학기 평점 3.5 이상" : "e.g. Undergrad CS major, GPA 3.5+, female-identifying"}
                  value={newEligibility}
                  onChange={e => setNewEligibility(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="w-1/2 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-500 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  {t("cancel")}
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-1/2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer flex items-center justify-center gap-1"
                >
                  {submitting && <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>}
                  {t("publishListing")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
