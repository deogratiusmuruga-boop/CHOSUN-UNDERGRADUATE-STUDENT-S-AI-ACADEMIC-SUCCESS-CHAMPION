import React, { useState, useEffect, useRef } from "react";
import { 
  Send, 
  Sparkles, 
  RefreshCw, 
  User, 
  Brain, 
  GraduationCap, 
  FileText, 
  Code, 
  DollarSign 
} from "lucide-react";
import { ChatMessage } from "../types";

interface ChatProps {
  lang: "en" | "ko";
  t: (key: any) => string;
  onNavigateToTab?: (tab: string) => void;
}

export default function Chat({ lang, t, onNavigateToTab }: ChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init",
      sender: "bot",
      text: "", // Will be filled dynamically by translating t("chatWelcome")
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Send message to chatbot API
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isTyping) return;

    const userMsg: ChatMessage = {
      id: "user_" + Date.now(),
      sender: "user",
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) {
      setInputMessage("");
    }
    setIsTyping(true);

    try {
      const response = await fetch("/api/chatbot/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.text,
          history: messages.slice(-8).map(m => m.id === "init" ? { ...m, text: t("chatWelcome") } : m) // Send translated context
        })
      });

      const data = await response.json();
      if (response.ok) {
        setMessages(prev => [...prev, {
          id: "bot_" + Date.now(),
          sender: "bot",
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }]);
      } else {
        throw new Error(data.error || "Failed to communicate with AI.");
      }
    } catch (error: any) {
      setMessages(prev => [...prev, {
        id: "bot_err_" + Date.now(),
        sender: "bot",
        text: lang === "ko" 
          ? `🎓 **학술 시스템 안내**\n\n조선대학교 AI 핵심 엔진에 접속하는 도중 연결 오류가 발생했습니다: *${error.message}*.\n\n여기에 오프라인 학술 팁이 있습니다: 25분간 집중하고 5분간 휴식하는 뽀모도로 공부법을 활용해 보세요. 인지 부하를 줄이고 기억력을 최대화할 수 있습니다!`
          : `🎓 **Academic System Notice**\n\nI encountered a connection hiccup while accessing the Chosun AI core engine: *${error.message}*. \n\nHere is an offline academic tip: Structure your day with 25-minute Pomodoro study intervals. It protects your cognitive load and maximizes grade recall!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage();
  };

  const quickPrompts = [
    {
      labelEn: "Explain Quantum Infinite Wells",
      labelKo: "양자 우물 방정식 설명",
      icon: <Brain size={12} className="text-blue-500" />,
      textEn: "Explain the mathematics and significance of the 1D Potential Infinite Square Well in Quantum Mechanics simply.",
      textKo: "양자역학에서 1차원 무한 장벽 우물의 수학적 원리와 의의를 이해하기 쉽게 설명해 줘."
    },
    {
      labelEn: "Draft STEM Scholarship Essay",
      labelKo: "이공계 장학금 에세이 초안",
      icon: <DollarSign size={12} className="text-emerald-500" />,
      textEn: "Write a short personal statement draft applying for the STEM Pioneer Excellence Scholarship emphasizing undergraduate leadership.",
      textKo: "학부생 리더십을 강조하여 이공계 우수 장학금(STEM Pioneer Excellence Scholarship) 지원을 위한 자기소개서 초안을 작성해 줘."
    },
    {
      labelEn: "Critique Go Consensus Code",
      labelKo: "Go Raft 합의 코드 크리틱",
      icon: <Code size={12} className="text-purple-500" />,
      textEn: "What are some typical engineering bugs and performance bottlenecks in custom Go Raft consensus implementations?",
      textKo: "Go 언어로 구현한 Raft 분산 합의 알고리즘에서 흔히 발생하는 엔지니어링 버그와 성능 병목 현상에 대해 설명해 줘."
    },
    {
      labelEn: "Double Integral Green's Theorem",
      labelKo: "그린 정리 & 이중적분 설명",
      icon: <FileText size={12} className="text-amber-500" />,
      textEn: "Explain Green's Theorem in 2D vector calculus and how to solve double integrals under it step-by-step.",
      textKo: "2차원 벡터 미적분학의 그린 정리를 설명하고, 이를 활용해 이중적분을 푸는 방법을 한글과 영어를 같이 써서 설명해 줘."
    }
  ];

  return (
    <div className="flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-full min-h-[500px]" id="copilot-chatbot-panel">
      
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse"></span>
          <div>
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
              <GraduationCap className="text-blue-600" size={16} />
              {t("copilotTab")}
            </h2>
            <p className="text-[10px] text-slate-400 font-mono">Academic AI • Response Latency 42ms</p>
          </div>
        </div>
        <button 
          onClick={() => setMessages([
            {
              id: "init",
              sender: "bot",
              text: "",
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ])}
          className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          title="Reset Conversation"
        >
          <RefreshCw size={13} />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-5 overflow-y-auto space-y-4 max-h-[360px] min-h-[250px]">
        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex gap-3 max-w-[90%] ${msg.sender === 'user' ? 'self-end ml-auto flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs border ${
              msg.sender === 'user' 
                ? 'bg-blue-50 text-blue-700 border-blue-200' 
                : 'bg-amber-50 text-amber-800 border-amber-200'
            }`}>
              {msg.sender === 'user' ? <User size={14} /> : "🎓"}
            </div>
            <div className="space-y-1">
              <div className={`p-3.5 rounded-2xl text-xs leading-relaxed whitespace-pre-line shadow-xs font-sans ${
                msg.sender === 'user'
                  ? 'bg-blue-600 text-white rounded-tr-none'
                  : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100'
              }`}>
                {msg.id === "init" ? t("chatWelcome") : msg.text}
              </div>
              <p className={`text-[9px] text-slate-400 ${msg.sender === 'user' ? 'text-right' : ''}`}>
                {msg.timestamp}
              </p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3 max-w-[85%]">
            <div className="w-8 h-8 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-xs">🎓</div>
            <div className="p-3 bg-slate-50 text-slate-500 rounded-2xl rounded-tl-none text-xs flex items-center gap-1.5 border border-slate-100">
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Suggested Quick prompts */}
      <div className="px-4 py-2 border-t border-slate-100/70 bg-slate-50/50">
        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">{t("askChosunAi")}</p>
        <div className="flex flex-wrap gap-1.5">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(lang === "ko" ? p.textKo : p.textEn)}
              className="px-2.5 py-1 bg-white hover:bg-blue-50 border border-slate-200/80 hover:border-blue-300 text-[10px] text-slate-600 hover:text-blue-700 font-medium rounded-md transition-all cursor-pointer flex items-center gap-1 shrink-0"
            >
              {p.icon}
              {lang === "ko" ? p.labelKo : p.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <form onSubmit={handleFormSubmit} className="p-3.5 bg-white border-t border-slate-100 flex gap-2">
        <input 
          type="text"
          placeholder={t("chatPlaceholder")}
          value={inputMessage}
          onChange={e => setInputMessage(e.target.value)}
          className="flex-grow bg-slate-50 border border-slate-200 rounded-full py-2.5 px-4.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-600"
        />
        <button 
          type="submit"
          disabled={!inputMessage.trim() || isTyping}
          className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-full transition-all shrink-0 cursor-pointer shadow-xs hover:shadow disabled:opacity-50"
        >
          <Send size={14} />
        </button>
      </form>
    </div>
  );
}
