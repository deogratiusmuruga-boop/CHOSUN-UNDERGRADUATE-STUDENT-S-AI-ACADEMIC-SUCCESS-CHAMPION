export interface AcademicResource {
  id: string;
  title: string;
  subject: string;
  type: 'note' | 'paper' | 'guide';
  description: string;
  content: string; // Detailed study notes or URL link
  author: string;
  date: string;
  downloads: number;
}

export interface Scholarship {
  id: string;
  name: string;
  description: string;
  amount: string;
  eligibility: string;
  deadline: string;
  category: 'merit' | 'financial' | 'international' | 'minority' | 'general';
  link: string;
}

export interface StudentProject {
  id: string;
  title: string;
  description: string;
  subject: string;
  category: 'research' | 'software' | 'design' | 'engineering' | 'business';
  techStack: string[];
  author: string;
  stars: number;
  codeUrl?: string;
  demoUrl?: string;
  feedback?: string[]; // AI feedback/peer reviews
}

export interface QuizQuestion {
  questionText: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface GeneratedQuiz {
  title: string;
  subject: string;
  questions: QuizQuestion[];
}

export interface StudyPlan {
  id: string;
  subject: string;
  targetGpa: string;
  durationWeeks: number;
  gpaTips: string[];
  schedule: { week: number; focus: string; tasks: string[] }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}
