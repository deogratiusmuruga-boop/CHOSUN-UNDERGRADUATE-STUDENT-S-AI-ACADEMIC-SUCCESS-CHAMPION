import React, { useState, useEffect } from "react";
import { 
  GraduationCap, 
  BookOpen, 
  Award, 
  FolderGit2, 
  Brain,
  Sparkles,
  Layers,
  LayoutDashboard,
  HelpCircle,
  Clock,
  CheckCircle2,
  Database,
  Cpu,
  Smartphone,
  Monitor
} from "lucide-react";

import Dashboard from "./components/Dashboard";
import Chat from "./components/Chat";
import Resources from "./components/Resources";
import Scholarships from "./components/Scholarships";
import Projects from "./components/Projects";
import PlannerAndQuiz from "./components/PlannerAndQuiz";

import { AcademicResource, Scholarship, StudentProject, StudyPlan } from "./types";
import { translations } from "./translations";

export default function App() {
  // Bilingual Language State
  const [lang, setLang] = useState<"en" | "ko">("ko"); // Default to Korean since it represents Chosun Univ, but with clean English fallback

  const t = (key: keyof typeof translations.en): string => {
    return translations[lang][key] || translations.en[key];
  };

  // Navigation states
  const [rightTab, setRightTab] = useState<string>("dashboard");
  const [mobileView, setMobileView] = useState<"chat" | "hub">("chat");
  
  // High-level data state
  const [resources, setResources] = useState<AcademicResource[]>([]);
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [projects, setProjects] = useState<StudentProject[]>([]);
  const [activePlan, setActivePlan] = useState<StudyPlan | null>(null);

  // Loading states
  const [loading, setLoading] = useState(true);

  // Fetch initial seed data from express backend
  useEffect(() => {
    async function initFetch() {
      try {
        const [resMat, resSch, resProj] = await Promise.all([
          fetch("/api/materials").then(r => r.json()),
          fetch("/api/scholarships").then(r => r.json()),
          fetch("/api/projects").then(r => r.json())
        ]);
        setResources(resMat);
        setScholarships(resSch);
        setProjects(resProj);
      } catch (err) {
        console.error("Error loading seed data:", err);
      } finally {
        setLoading(false);
      }
    }
    initFetch();
  }, []);

  // 1. ADD RESOURCE
  const handleAddResource = async (newRes: any) => {
    try {
      const response = await fetch("/api/materials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newRes)
      });
      if (response.ok) {
        const created = await response.json();
        setResources(prev => [created, ...prev]);
      } else {
        throw new Error("Failed to add resource.");
      }
    } catch (err) {
      console.error(err);
      alert("Error uploading resource.");
    }
  };

  // 2. DOWNLOAD RESOURCE
  const handleDownloadResource = async (id: string) => {
    try {
      const response = await fetch(`/api/materials/${id}/download`, {
        method: "POST"
      });
      if (response.ok) {
        setResources(prev => prev.map(r => r.id === id ? { ...r, downloads: r.downloads + 1 } : r));
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 3. ADD SCHOLARSHIP
  const handleAddScholarship = async (newSch: any) => {
    try {
      const response = await fetch("/api/scholarships", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSch)
      });
      if (response.ok) {
        const created = await response.json();
        setScholarships(prev => [...prev, created]);
      } else {
        throw new Error("Failed to add scholarship.");
      }
    } catch (err) {
      console.error(err);
      alert("Error adding scholarship listing.");
    }
  };

  // 4. ADD PROJECT
  const handleAddProject = async (newProj: any) => {
    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newProj)
      });
      if (response.ok) {
        const created = await response.json();
        setProjects(prev => [created, ...prev]);
      } else {
        throw new Error("Failed to publish project.");
      }
    } catch (err) {
      console.error(err);
      alert("Error publishing project artifact.");
    }
  };

  // 5. STAR/UPVOTE PROJECT
  const handleStarProject = async (id: string) => {
    try {
      const response = await fetch(`/api/projects/${id}/star`, {
        method: "POST"
      });
      if (response.ok) {
        setProjects(prev => prev.map(p => p.id === id ? { ...p, stars: p.stars + 1 } : p));
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 6. REQUEST AI PEER REVIEW FOR PROJECT
  const handleAiReviewProject = async (id: string): Promise<string[]> => {
    try {
      const response = await fetch(`/api/projects/${id}/ai-review`, {
        method: "POST"
      });
      if (response.ok) {
        const data = await response.json();
        setProjects(prev => prev.map(p => p.id === id ? { ...p, feedback: data.feedback } : p));
        return data.feedback;
      } else {
        throw new Error("Failed to generate AI feedback.");
      }
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // 7. STUDY PLAN GENERATION
  const handleGeneratePlan = async (subject: string, current: string, target: string) => {
    try {
      const response = await fetch("/api/chatbot/study-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject,
          currentGrade: current,
          targetGpa: target,
          durationWeeks: 4
        })
      });
      if (response.ok) {
        const plan = await response.json();
        setActivePlan(plan);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col justify-between" id="app-container">
      
      {/* Premium Global Header */}
      <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shadow-xs sticky top-0 z-30">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-gradient-to-tr from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-sm">
            <GraduationCap className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-slate-800 uppercase flex items-center gap-1.5">
              CHOSUN <span className="text-blue-600">UNDERGRADUATE</span>
            </h1>
            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">{t("academicWorkspace")}</p>
          </div>
        </div>

        {/* Global Stats bar - desktop only */}
        <div className="hidden lg:flex items-center gap-6 text-xs">
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
            <span className="text-slate-500 font-semibold">{t("studentStatus")}:</span>
            <span className="font-bold text-slate-800">{t("alexRivera")} ({t("year3")})</span>
          </div>
          <div className="flex items-center gap-1.5 bg-blue-50/50 border border-blue-100 px-3 py-1.5 rounded-lg">
            <span className="text-blue-600 font-semibold">{t("activeGpa")}:</span>
            <span className="font-bold text-blue-700">3.82 / 4.0</span>
          </div>
        </div>
        
        {/* Language selector & User Card */}
        <div className="flex items-center gap-4">
          {/* Gorgeous Language Toggle */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 shadow-inner">
            <button
              onClick={() => setLang("en")}
              className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-all cursor-pointer ${
                lang === "en"
                  ? "bg-white text-blue-600 shadow-sm border border-slate-200/20"
                  : "text-slate-400 hover:text-slate-800"
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLang("ko")}
              className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-all cursor-pointer ${
                lang === "ko"
                  ? "bg-white text-blue-600 shadow-sm border border-slate-200/20"
                  : "text-slate-400 hover:text-slate-800"
              }`}
            >
              한국어
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-800">{t("alexRivera")}</p>
              <p className="text-[9px] text-slate-400 uppercase tracking-wider font-mono">{t("computerScience")}</p>
            </div>
            <div className="w-9 h-9 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-700 shadow-inner">
              AR
            </div>
          </div>
        </div>
      </header>

      {/* Responsive Viewport Toggle for Mobile view (hidden on desktop) */}
      <div className="lg:hidden bg-white border-b border-slate-200/80 p-2.5 flex justify-center gap-2 sticky top-16 z-20 shadow-xs">
        <button
          onClick={() => setMobileView("chat")}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            mobileView === "chat"
              ? "bg-blue-600 text-white shadow-sm"
              : "bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100"
          }`}
        >
          💬 {t("copilotTab")}
          <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
        </button>
        <button
          onClick={() => setMobileView("hub")}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            mobileView === "hub"
              ? "bg-blue-600 text-white shadow-sm"
              : "bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100"
          }`}
        >
          📂 {t("registryHubTab")}
        </button>
      </div>

      {/* Main Split View Grid (Full width & fluid bounds) */}
      <main className="flex-grow p-4 md:p-6 w-full max-w-7xl mx-auto flex flex-col" id="main-academic-grid">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-4 flex-grow">
            <span className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin"></span>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Synchronizing Chosun Database Clusters...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch flex-grow">
            
            {/* LEFT COLUMN: Persistent Interactive Chat (visible on desktop always, or on mobile when active) */}
            <div className={`lg:col-span-5 h-full ${mobileView === 'chat' ? 'block' : 'hidden lg:block'}`}>
              <Chat 
                lang={lang}
                t={t}
                onNavigateToTab={(target) => {
                  setRightTab(target);
                  setMobileView("hub");
                }}
              />
            </div>

            {/* RIGHT COLUMN: Tabbed Academic Resources, Scholarships, Portfolios, and Planner */}
            <div className={`lg:col-span-7 flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-full ${
              mobileView === 'hub' ? 'block' : 'hidden lg:block'
            }`}>
              
              {/* Tab Selector Header for Right Pane */}
              <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between overflow-x-auto shrink-0 scrollbar-none">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setRightTab("dashboard")}
                    className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      rightTab === "dashboard"
                        ? "bg-white text-blue-600 shadow-sm border border-slate-200/50"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    <LayoutDashboard size={13} />
                    {t("tabOverview")}
                  </button>

                  <button
                    onClick={() => setRightTab("resources")}
                    className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      rightTab === "resources"
                        ? "bg-white text-blue-600 shadow-sm border border-slate-200/50"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    <BookOpen size={13} />
                    {t("tabLectureFiles")}
                  </button>

                  <button
                    onClick={() => setRightTab("scholarships")}
                    className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      rightTab === "scholarships"
                        ? "bg-white text-blue-600 shadow-sm border border-slate-200/50"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    <Award size={13} />
                    {t("tabGrants")}
                  </button>

                  <button
                    onClick={() => setRightTab("projects")}
                    className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      rightTab === "projects"
                        ? "bg-white text-blue-600 shadow-sm border border-slate-200/50"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    <FolderGit2 size={13} />
                    {t("tabPortfolios")}
                  </button>

                  <button
                    onClick={() => setRightTab("planner")}
                    className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                      rightTab === "planner"
                        ? "bg-white text-blue-600 shadow-sm border border-slate-200/50"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    <Sparkles size={13} className="text-indigo-500" />
                    {t("tabPlannerQuiz")}
                  </button>
                </div>
              </div>

              {/* Hub Workspace Body */}
              <div className="p-5 md:p-6 overflow-y-auto flex-1 max-h-[550px] lg:max-h-[600px] min-h-[350px]">
                {rightTab === "dashboard" && (
                  <Dashboard 
                    lang={lang}
                    t={t}
                    onNavigate={(tab) => {
                      if (tab === "chat") {
                        setRightTab("planner");
                        setMobileView("hub");
                      } else {
                        setRightTab(tab);
                        setMobileView("hub");
                      }
                    }}
                    resources={resources}
                    scholarships={scholarships}
                    projects={projects}
                    onGeneratePlan={handleGeneratePlan}
                    activePlan={activePlan}
                  />
                )}

                {rightTab === "resources" && (
                  <Resources 
                    lang={lang}
                    t={t}
                    resources={resources}
                    onAddResource={handleAddResource}
                    onDownloadResource={handleDownloadResource}
                  />
                )}

                {rightTab === "scholarships" && (
                  <Scholarships 
                    lang={lang}
                    t={t}
                    scholarships={scholarships}
                    onAddScholarship={handleAddScholarship}
                  />
                )}

                {rightTab === "projects" && (
                  <Projects 
                    lang={lang}
                    t={t}
                    projects={projects}
                    onAddProject={handleAddProject}
                    onStarProject={handleStarProject}
                    onAiReviewProject={handleAiReviewProject}
                  />
                )}

                {rightTab === "planner" && (
                  <PlannerAndQuiz 
                    lang={lang}
                    t={t}
                    activePlan={activePlan}
                    onSetActivePlan={setActivePlan}
                  />
                )}
              </div>
            </div>

          </div>
        )}
      </main>

      {/* Orchestrator Status Footer */}
      <footer className="h-11 bg-white border-t border-slate-200 px-6 flex flex-col sm:flex-row items-center justify-between gap-2 py-2 sm:py-0 shrink-0 select-none z-10">
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-1">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">{t("coreOnline")}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">{t("sqlOk")}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">{t("aiActive")}</span>
          </div>
        </div>
        <div className="text-[9px] text-slate-400 font-mono flex items-center gap-2">
          <span>{t("uptime")}: 142h 12m</span>
          <span>•</span>
          <span>{t("latency")}: 42ms</span>
        </div>
      </footer>

    </div>
  );
}
